﻿namespace SoftJail.DataProcessor.ExportDto
{ 
    public class ExportOfficerDto
    {
        //  {
        //    "OfficerName": "Hailee Kennon",
        //    "Department": "ArtificialIntelligence"
        //  },
        public string OfficerName { get; set; }
        public string Department { get; set; }
    }
}