﻿namespace VaporStore.Datasets.Dto
{
    public class ExportTagDto
    {
        public string Name { get; set; }
    }
}