﻿namespace P01_HospitalDatabase
{
    public static class Configuration
    {
        public const string ConnectionString = "Server=DESKTOP-7IFBEA4;Database=Hospital;Integrated Security=True;";
    }
}
