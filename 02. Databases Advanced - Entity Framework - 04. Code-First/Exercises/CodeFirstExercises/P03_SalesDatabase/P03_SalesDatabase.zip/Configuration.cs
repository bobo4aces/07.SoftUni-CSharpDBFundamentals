﻿namespace P03_SalesDatabase
{
    public static class Configuration
    {
        public const string ConnectionString = "Server=DESKTOP-7IFBEA4;Database=Sales;Integrated Security=True;";
    }
}
