﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ADONetExercises
{
    public static class Configuration
    {
        public const string ConnectionString = @"Server=DESKTOP-7IFBEA4;;Integrated Security=True";
    }
}
