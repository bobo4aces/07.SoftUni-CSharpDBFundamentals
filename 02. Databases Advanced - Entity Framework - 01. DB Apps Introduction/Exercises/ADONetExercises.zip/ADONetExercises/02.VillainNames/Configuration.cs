﻿using System;
using System.Collections.Generic;
using System.Text;

namespace _02.VillainNames
{
    public static class Configuration
    {
        public const string ConnectionString = @"Server=DESKTOP-7IFBEA4;Database=MinionsDB;Integrated Security=True";
    }
}
