﻿namespace BillsPaymentSystem.Models.Enums
{
    public enum PaymentType
    {
        BankAccount,
        CreditCard
    }
}
