﻿using System;
using System.Collections.Generic;
using System.Text;

namespace P01_StudentSystem
{
    public class Configuration
    {
        public const string ConnectionString = "Server=DESKTOP-7IFBEA4;Database=StudentSystem;Integrated Security=True;";
    }
}
