﻿namespace P03_FootballBetting
{
    public class Configuration
    {
        public const string ConnectionString = "Server=DESKTOP-7IFBEA4;Database=FootballBetting;Integrated Security=True;";
    }
}
